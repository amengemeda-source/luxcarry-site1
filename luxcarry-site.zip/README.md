# LUXCARRY SYD — Drop Microsite

Vite + React + Tailwind starter for your drop. DM-only access + waitlist (screenshot → DM).

## Scripts
- `npm install`
- `npm run dev` (local preview)
- `npm run build` (production build)
- `npm run preview` (serve the build)

## Deploy on Vercel
1) Push this folder to a GitHub repo (e.g. `luxcarry-site`).
2) In Vercel: New Project → Import repo → Build: `npm run build` → Output: `dist`.
3) Put the Vercel URL in your Instagram/TikTok bio.

## Configuration
Edit `src/App.jsx` → the `CONFIG` block (brand, handles, countdown, reserved count, etc).

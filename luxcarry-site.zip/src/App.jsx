import React, { useEffect, useMemo, useState } from "react";

const CONFIG = {
  BRAND_NAME: "LUXCARRY SYD",
  TAGLINE: "Limited luxury travel case for connoisseurs.",
  CITY: "Sydney, Australia",
  DROP_TOTAL: 45,
  LAUNCH_AT_ISO: "2025-08-24T18:00:00+10:00", // set "" to hide countdown
  IG_HANDLE: "luxcarry_syd",
  TIKTOK_HANDLE: "luxcarry_syd",
  IG_BROADCAST_URL: "",
  WAITLIST_FORM_URL: "",
  SHOW_DEPOSIT_INFO: true,
  RESERVED_COUNT: 13,
};

function useCountdown(targetISO) {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);
  const target = useMemo(() => (targetISO ? new Date(targetISO) : null), [targetISO]);
  if (!target) return null;
  const diff = target.getTime() - now.getTime();
  if (diff <= 0) return { d: 0, h: 0, m: 0, s: 0, expired: true };
  const d = Math.floor(diff / (1000 * 60 * 60 * 24));
  const h = Math.floor((diff / (1000 * 60 * 60)) % 24);
  const m = Math.floor((diff / (1000 * 60)) % 60);
  const s = Math.floor((diff / 1000) % 60);
  return { d, h, m, s, expired: false };
}

function AgeGate() {
  const [open, setOpen] = useState(false);
  useEffect(() => {
    const ok = localStorage.getItem("zv_age_ok");
    if (!ok) setOpen(true);
  }, []);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-black/80 p-6">
      <div className="max-w-md w-full rounded-2xl bg-neutral-900 border border-neutral-800 p-6 text-neutral-100">
        <h2 className="text-2xl font-semibold tracking-tight">Age Verification</h2>
        <p className="mt-3 text-neutral-300 text-sm leading-relaxed">
          This site showcases an adult-only luxury accessory. No tobacco is sold or depicted.
        </p>
        <div className="mt-6 flex gap-3">
          <button
            onClick={() => { localStorage.setItem("zv_age_ok", "1"); setOpen(false); }}
            className="inline-flex items-center justify-center rounded-xl px-4 py-2.5 bg-white text-black font-medium hover:opacity-90"
          >
            I am 18+
          </button>
          <a
            href="https://www.google.com"
            className="inline-flex items-center justify-center rounded-xl px-4 py-2.5 border border-neutral-700 text-neutral-200 hover:bg-neutral-800"
          >
            Exit
          </a>
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value }) {
  return (
    <div className="flex flex-col items-center">
      <div className="text-3xl sm:text-4xl font-semibold">{value}</div>
      <div className="mt-1 text-xs uppercase tracking-widest text-neutral-400">{label}</div>
    </div>
  );
}

function ProgressBar({ total, reserved }) {
  const pct = Math.min(100, Math.round((reserved / total) * 100));
  return (
    <div className="w-full">
      <div className="flex justify-between text-xs text-neutral-400 mb-2">
        <span>Reserved <span className="text-neutral-200">{reserved}</span> / {total}</span>
        <span>{pct}%</span>
      </div>
      <div className="h-2.5 rounded-full bg-neutral-800 overflow-hidden">
        <div className="h-full bg-white" style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

export default function App() {
  const c = CONFIG;
  const countdown = useCountdown(c.LAUNCH_AT_ISO);

  const [copied, setCopied] = useState(false);
  const dmTemplate = `Hi ${c.BRAND_NAME}, I want access.\nName: \nSuburb: \nPayment: bank transfer or cash pick-up ($50 deposit)\nDelivery: Sydney handover`;

  const dmLink = `https://www.instagram.com/${c.IG_HANDLE}/`;
  const ttLink = `https://www.tiktok.com/@${c.TIKTOK_HANDLE}`;

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-50">
      <AgeGate />

      {/* Header */}
      <header className="sticky top-0 z-40 backdrop-blur supports-[backdrop-filter]:bg-neutral-950/60 bg-neutral-950/80 border-b border-neutral-800">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-8 w-8 rounded-xl bg-gradient-to-br from-neutral-200 to-neutral-500" />
            <span className="font-semibold tracking-tight">{c.BRAND_NAME}</span>
          </div>
          <nav className="hidden sm:flex items-center gap-4 text-sm text-neutral-300">
            <a href="#features" className="hover:text-white">Features</a>
            <a href="#waitlist" className="hover:text-white">Waitlist</a>
            <a href="#rules" className="hover:text-white">Rules</a>
          </nav>
          <div className="flex items-center gap-2">
            <a href={dmLink} target="_blank" className="hidden sm:inline-flex rounded-xl px-3 py-2 bg-white text-black text-sm font-medium hover:opacity-90" rel="noreferrer">
              DM "CARRY"
            </a>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-neutral-800/30 via-neutral-900 to-neutral-950" />
        <div className="max-w-6xl mx-auto px-4 py-16 sm:py-24 relative">
          <h1 className="text-3xl sm:text-5xl font-semibold tracking-tight">{c.BRAND_NAME}</h1>
          <p className="mt-4 max-w-2xl text-neutral-300">
            Built right. Clean carry.{" "}
            <span className="text-neutral-200 font-medium">Only {c.DROP_TOTAL} pieces.</span>
          </p>
          <p className="mt-2 max-w-2xl text-neutral-300">
            Craft-first, no fluff. Tight stitching, rich grain, cedar divide, secure strap. Private drop for those who know.
            No public links — DM <b>"CARRY"</b> or join the list below.
          </p>

          <div className="mt-6 flex flex-wrap items-center gap-3">
            <a href="#waitlist" className="rounded-2xl px-5 py-2.5 bg-white text-black font-medium hover:opacity-90">Request Access</a>
            <a href={dmLink} target="_blank" className="rounded-2xl px-5 py-2.5 border border-neutral-700 text-neutral-200 hover:bg-neutral-900" rel="noreferrer">DM on Instagram</a>
            <a href={ttLink} target="_blank" className="rounded-2xl px-5 py-2.5 border border-neutral-700 text-neutral-200 hover:bg-neutral-900" rel="noreferrer">TikTok</a>
          </div>

          {/* Stats / Countdown */}
          <div className="mt-10 grid grid-cols-2 sm:grid-cols-4 gap-6 max-w-3xl">
            <Stat label="City" value={c.CITY} />
            <Stat label="Release" value={"Wave 1"} />
            <Stat label="Pieces" value={`${c.DROP_TOTAL}`} />
            <Stat label="Status" value={countdown ? (countdown.expired ? "Live" : "Soon") : "TBA"} />
          </div>

          {countdown && (
            <div className="mt-10">
              <div className="text-sm uppercase tracking-widest text-neutral-400 mb-2">Launch in</div>
              <div className="flex items-center gap-4 text-3xl sm:text-4xl">
                <div className="tabular-nums">{countdown.d}<span className="text-base ml-2">d</span></div>
                <div className="tabular-nums">{countdown.h}<span className="text-base ml-2">h</span></div>
                <div className="tabular-nums">{countdown.m}<span className="text-base ml-2">m</span></div>
                <div className="tabular-nums">{countdown.s}<span className="text-base ml-2">s</span></div>
              </div>
            </div>
          )}

          {/* Progress */}
          <div className="mt-10 max-w-md">
            <ProgressBar total={c.DROP_TOTAL} reserved={c.RESERVED_COUNT} />
          </div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="max-w-6xl mx-auto px-4 py-16">
        <h2 className="text-2xl sm:text-3xl font-semibold tracking-tight">Built right. Clean carry.</h2>
        <p className="mt-3 text-neutral-300 max-w-3xl">
          Craft-first, no fluff. Tight stitching, rich grain, cedar divide, secure strap. Private drop for those who know.
          No public links — DM <b>"CARRY"</b> or join the list below.
        </p>
        <div className="mt-8 grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { title: "Sydney Meet-ups", desc: "Meet-ups anywhere in Sydney." },
            { title: "Insured Post", desc: "Australia-wide insured shipping available." },
            { title: "Private Access", desc: "No public cart. DM "CARRY" to jump the queue." },
            { title: "Request Access", desc: "Tap the button below to join the list." },
          ].map((f, i) => (
            <div key={i} className="rounded-2xl border border-neutral-800 p-5 bg-neutral-950/60">
              <div className="text-lg font-medium">{f.title}</div>
              <div className="mt-2 text-neutral-300 text-sm">{f.desc}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Rules / Claim */}
      {c.SHOW_DEPOSIT_INFO && (
        <section id="rules" className="max-w-6xl mx-auto px-4 pb-4">
          <div className="rounded-2xl border border-neutral-800 p-6 bg-neutral-950/60">
            <h3 className="text-xl font-semibold">Drop rules (read before joining)</h3>
            <ul className="mt-3 space-y-2 text-neutral-300 text-sm list-disc pl-5">
              <li>Accessory only. No tobacco is sold or depicted.</li>
              <li>Claim windows are 15 minutes. First paid = lowest available serial.</li>
              <li>Sydney handover or insured post.</li>
            </ul>
          </div>
        </section>
      )}

      {/* Waitlist */}
      <section id="waitlist" className="max-w-6xl mx-auto px-4 py-16">
        <div className="grid lg:grid-cols-2 gap-10 items-start">
          <div>
            <h2 className="text-2xl sm:text-3xl font-semibold tracking-tight">Request access</h2>
            <p className="mt-3 text-neutral-300">
              Priority access is assigned in order of verified entries. Or DM{" "}
              <a href={dmLink} className="text-white underline ml-1" target="_blank" rel="noreferrer">@{c.IG_HANDLE}</a>{" "}
              with the word <span className="text-white font-medium">"CARRY"</span> to be added manually.
            </p>

            <div className="mt-6 flex flex-wrap gap-3">
              <a href={dmLink} target="_blank" className="rounded-xl px-4 py-2.5 bg-white text-black font-medium hover:opacity-90" rel="noreferrer">
                DM “CARRY”
              </a>
              {c.IG_BROADCAST_URL && (
                <a href={c.IG_BROADCAST_URL} target="_blank" className="rounded-xl px-4 py-2.5 border border-neutral-700 text-neutral-200 hover:bg-neutral-900" rel="noreferrer">
                  Broadcast Channel
                </a>
              )}
              <button
                onClick={async () => { await navigator.clipboard.writeText(dmTemplate); setCopied(true); setTimeout(() => setCopied(false), 2000); }}
                className="rounded-xl px-4 py-2.5 border border-neutral-700 text-neutral-200 hover:bg-neutral-900"
              >
                {copied ? "Copied DM template ✓" : "Copy DM template"}
              </button>
            </div>

            <div className="mt-8 rounded-2xl border border-neutral-800 p-5 bg-neutral-950/60">
              <div className="text-sm text-neutral-300">
                <div className="font-medium text-neutral-200">What happens next?</div>
                <ol className="list-decimal pl-5 mt-2 space-y-1">
                  <li>We confirm your details (suburb, payment preference).</li>
                  <li>Deposit only — or for cash pick-ups, $50 deposit holds your spot.</li>
                  <li>Serial assigned in payment order. Live updates via Stories.</li>
                </ol>
              </div>
            </div>
          </div>

          <div>
            {c.WAITLIST_FORM_URL ? (
              <div className="w-full rounded-2xl overflow-hidden border border-neutral-800 bg-neutral-950/60">
                <iframe src={c.WAITLIST_FORM_URL} className="w-full h-[640px]" title="Vault Waitlist Form" />
              </div>
            ) : (
              <div className="rounded-2xl border border-neutral-800 p-6 bg-neutral-950/60">
                <div className="text-neutral-200 font-medium">No form connected</div>
                <p className="mt-2 text-neutral-300 text-sm">
                  Fill out the quick form, take a screenshot, and DM it to us on Instagram:{" "}
                  <a href={dmLink} target="_blank" className="underline text-white" rel="noreferrer">@luxcarry_syd</a>.
                </p>
                <QuickIntake />
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-neutral-800">
        <div className="max-w-6xl mx-auto px-4 py-10 grid sm:grid-cols-2 gap-6 items-center">
          <div className="text-sm text-neutral-400">
            © {new Date().getFullYear()} {c.BRAND_NAME}. Accessory only.
          </div>
          <div className="sm:text-right text-sm text-neutral-400">
            <a href={dmLink} target="_blank" className="hover:text-neutral-200" rel="noreferrer">Instagram</a>
            <span className="mx-2">•</span>
            <a href={ttLink} target="_blank" className="hover:text-neutral-200" rel="noreferrer">TikTok</a>
          </div>
        </div>
      </footer>
    </div>
  );
}

function QuickIntake() {
  const [form, setForm] = useState({ name: "", suburb: "", phone: "", email: "", payment: "bank", delivery: "handover" });
  const payload = `CARRY WAITLIST\nName: ${form.name}\nSuburb: ${form.suburb}\nPhone: ${form.phone}\nEmail: ${form.email}\nPayment: ${form.payment}\nDelivery: ${form.delivery}`;

  return (
    <div className="mt-5">
      <div className="grid sm:grid-cols-2 gap-3">
        <Input label="Full name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
        <Input label="Suburb / City" value={form.suburb} onChange={(e) => setForm({ ...form, suburb: e.target.value })} />
        <Input label="Phone" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
        <Input label="Email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
        <Select label="Payment preference" value={form.payment} onChange={(e) => setForm({ ...form, payment: e.target.value })}>
          <option value="bank">Bank transfer</option>
        </Select>
        <Select label="Delivery preference" value={form.delivery} onChange={(e) => setForm({ ...form, delivery: e.target.value })}>
          <option value="handover">Sydney handover</option>
        </Select>
      </div>

      <div className="mt-4 text-sm text-neutral-300">
        Fill out these fields, take a screenshot, and DM it to us via Instagram{" "}
        <a href={`https://www.instagram.com/${CONFIG.IG_HANDLE}/`} target="_blank" className="underline text-white" rel="noreferrer">
          @{CONFIG.IG_HANDLE}
        </a>.
      </div>
      <div className="mt-3 rounded-xl border border-neutral-800 p-4 bg-neutral-950/60">
        <div className="text-xs text-neutral-400">Preview (screenshot this and DM):</div>
        <pre className="mt-2 whitespace-pre-wrap text-neutral-300 text-xs border border-neutral-800 rounded-lg p-3 bg-neutral-950/60">
{payload}
        </pre>
      </div>
    </div>
  );
}

function Input({ label, ...props }) {
  return (
    <label className="text-sm text-neutral-300">
      <span className="block mb-1 text-neutral-200">{label}</span>
      <input {...props} className="w-full rounded-xl border border-neutral-800 bg-neutral-900 px-3 py-2.5 outline-none focus:ring-2 focus:ring-white/20" />
    </label>
  );
}

function Select({ label, children, ...props }) {
  return (
    <label className="text-sm text-neutral-300">
      <span className="block mb-1 text-neutral-200">{label}</span>
      <select {...props} className="w-full rounded-xl border border-neutral-800 bg-neutral-900 px-3 py-2.5 outline-none focus:ring-2 focus:ring-white/20">
        {children}
      </select>
    </label>
  );
}
